# iso-fits
Python module for calculating hole/shaft tolerances per ISO 286-1
